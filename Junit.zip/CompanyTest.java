

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class CompanyTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class CompanyTest
{
    /**
     * Default constructor for test class CompanyTest
     */
    public CompanyTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void TestCompany()
    {
        Company company1 = new Company("ray", 100000, 100);
        assertEquals(1, company1.getCompanyID());
        assertEquals("ray", company1.getName());
        assertNotNull(company1.getStock());
        assertEquals("false", company1.isCompanyInsolvent());
        company1.issueStock();
        company1.setInsolvent();
    }

    @Test
    public void TestName()
    {
        Company company1 = new Company("ray", 10000, 100);
        company1.setName("raaa");
        assertEquals("raaa", company1.getName());
        assertEquals(1, company1.getCompanyID());
    }
}


