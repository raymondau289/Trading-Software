

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PortfolioTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PortfolioTest
{
    /**
     * Default constructor for test class PortfolioTest
     */
    public PortfolioTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void TestCash()
    {
        Portfolio portfoli1 = new Portfolio("ray", 10000);
        portfoli1.addCash(100);
        assertEquals(10100, portfoli1.getCash());
    }

    @Test
    public void TestCashout()
    {
        Portfolio portfoli2 = new Portfolio("ray", 1000);
        assertEquals(100, portfoli2.withdrawCash(100));
        assertEquals(900, portfoli2.getCash());
    }

    

    @Test
    public void TestGetname()
    {
        Portfolio portfoli1 = new Portfolio("ray", 10000);
        assertEquals("ray", portfoli1.getName());
        portfoli1.setName("tt");
        assertEquals("tt", portfoli1.getName());
    }

    @Test
    public void TestTotal()
    {
        Portfolio portfoli2 = new Portfolio("ray", 1000);
        portfoli2.removeInsolventStock();
        portfoli2.removeInsolventStock();
        assertEquals(1000, portfoli2.getTotalWorth(), 0.2);
        assertEquals(0, portfoli2.getSize());
        assertEquals(2, portfoli2.getClientID());
        assertEquals(0, portfoli2.getAssetValue(), 0.1);
    }
}





