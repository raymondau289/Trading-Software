

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class StockTest.
 *
 * @author  (Tszman Au)
 * @version (3.00, 04 may 2017)
 */
public class StockTest
{
    /**
     * Default constructor for test class StockTest
     */
    public StockTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void Teststockprice()
    //test the stockprice and update function
    {
        Stock stock1 = new Stock(1, "new", 10000);
        assertEquals(10000, stock1.getPrice(), 0.1);
        stock1.updateStockPrice(100);
        assertEquals(100, stock1.getPrice(), 0.1);
    }

    @Test
    public void Testname()
    //test get stockname and set the new stockname
    {
        Stock stock1 = new Stock(1, "new", 10000);
        assertEquals("new", stock1.getStockName());
        stock1.setStockName("tt");
        assertEquals("tt", stock1.getStockName());
    }
}


