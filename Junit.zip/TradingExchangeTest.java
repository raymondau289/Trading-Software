

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class TradingExchangeTest.
 *
 * @author  (Tszman Au)
 * @version (3.00, 04 may 2017)
 */
public class TradingExchangeTest
{
    /**
     * Default constructor for test class TradingExchangeTest
     */
    public TradingExchangeTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void Test()
    // test the tradingexchange sale function
    {
        TradingExchange tradingE1 = new TradingExchange();
        tradingE1.printHashMap();
        assertNull(tradingE1.getForSale());
    }
}

